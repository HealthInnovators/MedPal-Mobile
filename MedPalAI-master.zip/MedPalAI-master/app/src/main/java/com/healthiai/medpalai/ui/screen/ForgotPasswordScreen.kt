package com.healthiai.medpalai.ui.screen

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.painter.Painter
import androidx.compose.ui.res.colorResource
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.healthiai.medpalai.R

@OptIn(ExperimentalMaterial3Api::class)
@Composable

fun ForgotPasswordScreen(navController: NavController) {
    var email by remember { mutableStateOf(TextFieldValue("")) }
    var isEmailValid by remember { mutableStateOf(true) }
    var isFocused by remember { mutableStateOf(false) }
    var showDialog by remember { mutableStateOf(false) }


    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(text = "Forgot Your Password ?", style = MaterialTheme.typography.bodyLarge, fontWeight = FontWeight.Bold, fontSize = 24.sp)

        Spacer(modifier = Modifier.height(16.dp))

        Text(
            text = "Enter your email and we will send you a verification code after resetting your password.",
            style = TextStyle(
                fontSize = 16.sp, // Set the font size for the message
                color = colorResource(id = R.color.light_gray) // Set the light color for the message
            ),
            modifier = Modifier.padding(bottom = 16.dp) // Optional: Add padding
        )

        TextField(
            value = email,
            onValueChange = {
                email = it
                isEmailValid = isEmailIDValid(it.text)
            },
            label = { Text(text = "Email Address", color = if (isFocused) colorResource(id = R.color.sea_green) else colorResource(id = R.color.black))},
            isError = !isEmailValid,
            modifier = Modifier
                .fillMaxWidth()
                .onFocusChanged { focusState ->
                    isFocused = focusState.isFocused
                },
            colors = TextFieldDefaults.textFieldColors(
                focusedIndicatorColor = colorResource(id = if (isFocused) R.color.sea_green else R.color.white), // Change this to your desired color
                containerColor = colorResource(id = android.R.color.transparent),
                unfocusedIndicatorColor = colorResource(id = R.color.white)

            )
        )

        if (!isEmailValid) {
            Text(text = "Invalid email address", color = MaterialTheme.colorScheme.error)
        }

        Spacer(modifier = Modifier.height(16.dp))

        Button(
            shape = RoundedCornerShape(14.dp),
            modifier = Modifier
                .fillMaxWidth()
                .height(46.dp),
            onClick = {
                // Handle forgot password logic here
                if (isEmailValid) {
                    // Perform the forgot password request
                    showDialog = true
                }
            },
            enabled = isEmailValid,
            colors = ButtonDefaults.buttonColors(
                containerColor =  colorResource(R.color.sea_green),// Change this to your desired color
                contentColor = Color.White // Change this to your desired content color
            )

        ) {
            Text(text = "Submit", color = colorResource(R.color.white))
        }
    }
    if (showDialog) {
        AlertDialog(
            onDismissRequest = { showDialog = false },
            title = { Text(text = "Success") },
            text = { Text("Your password has been successfully changed.") },
            confirmButton = {
                Button(
                    onClick = { showDialog = false },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = colorResource(id = R.color.sea_green), // Background color
                        contentColor = colorResource(id = R.color.white) // Text color
                    )
                ) {
                    Text("OK")
                }
            }
        )
    }
}

fun isEmailIDValid(email: String): Boolean {
    return android.util.Patterns.EMAIL_ADDRESS.matcher(email).matches()
}
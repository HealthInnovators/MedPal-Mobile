package com.healthiai.medpalai.ui.screen

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonColors
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.colorResource
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.healthiai.medpalai.R

@Composable
fun OnboardFlow(skip: Boolean, navController: NavController, changeVal: (Boolean) -> Unit) {
    Column() {
        var step by remember { mutableStateOf(1) }
        Row() {
            Spacer(modifier = Modifier.weight(1f))
            Button(
                onClick = {
                    changeVal(!skip)
                    navController.navigate("login") },
                colors = ButtonDefaults.buttonColors(containerColor = Color.Transparent)

            ) {
                Text(text = "Skip", color = Color.Gray)
            }
        }
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center,
            modifier = Modifier
                .fillMaxWidth()
                .fillMaxHeight()
        ) {
            if (step == 1) {
                Image(painter = painterResource(id = R.drawable.onboard_1),
                    contentDescription = "",
                    contentScale = ContentScale.Fit,
                    modifier = Modifier.size(300.dp))
                Text(text = "Consult only with a doctor you trust",
                    fontSize = 22.sp,
                    fontWeight = FontWeight.Bold)
            } else if (step == 2) {
                Image(painter = painterResource(id = R.drawable.onboard_2),
                    contentDescription = "",
                    contentScale = ContentScale.Fit,
                    modifier = Modifier.size(300.dp))
                Text(text = "Find a lot of specialist doctors in one place",
                    fontSize = 22.sp,
                    fontWeight = FontWeight.Bold)
            } else {
                Image(painter = painterResource(id = R.drawable.onboard_3),
                    contentDescription = "",
                    contentScale = ContentScale.Fit,
                    modifier = Modifier.size(300.dp))
                Text(text = "Get connected with our Online Consultation",
                    fontSize = 22.sp,
                    fontWeight = FontWeight.Bold)
            }
            Spacer(modifier = Modifier.height(20.dp))
            Row(verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.height(40.dp)) {
                SetStepUI(step = step)
                Spacer(modifier = Modifier.weight(1f))
                Button(modifier = Modifier.weight(1f, fill = false),
                    colors = ButtonDefaults.buttonColors(containerColor = colorResource(id = R.color.sea_green)),
                    onClick = {
                        if (step == 1) step = 2
                        else if (step == 2) step = 3
                        else if (step == 3) changeVal(!skip)
                    }) {
                    Text(text = "Next")
                }
            }
        }
    }
}

@Composable
fun SetStepUI(step: Int) {
    Row {
        if (step == 1) {
            Box(modifier = Modifier
                .background(color = colorResource(id = R.color.sea_green))
                .width(10.dp).height(5.dp))
            Spacer(modifier = Modifier.width(6.dp))
            Box(modifier = Modifier
                .background(color = Color.Gray)
                .width(10.dp).height(5.dp))
            Spacer(modifier = Modifier.width(6.dp))
            Box(modifier = Modifier
                .background(color = Color.Gray)
                .width(10.dp).height(5.dp))
        } else if (step == 2) {
            Box(modifier = Modifier
                .background(color = Color.Gray)
                .width(10.dp).height(5.dp))
            Spacer(modifier = Modifier.width(6.dp))
            Box(modifier = Modifier
                .background(color = colorResource(id = R.color.sea_green))
                .width(10.dp).height(5.dp))
            Spacer(modifier = Modifier.width(6.dp))
            Box(modifier = Modifier
                .background(color = Color.Gray)
                .width(10.dp).height(5.dp))
        } else {
            Box(modifier = Modifier
                .background(color = Color.Gray)
                .width(10.dp).height(5.dp))
            Spacer(modifier = Modifier.width(6.dp))
            Box(modifier = Modifier
                .background(color = Color.Gray)
                .width(10.dp).height(5.dp))
            Spacer(modifier = Modifier.width(6.dp))
            Box(modifier = Modifier
                .background(color = colorResource(id = R.color.sea_green))
                .width(10.dp).height(5.dp))
        }
    }
}
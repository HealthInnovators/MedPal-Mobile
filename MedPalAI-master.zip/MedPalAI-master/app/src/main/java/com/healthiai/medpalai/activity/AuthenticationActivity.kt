package com.healthiai.medpalai.activity

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.colorResource
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.healthiai.medpalai.ui.theme.MedPalAITheme
import com.healthiai.medpalai.R
import com.healthiai.medpalai.ui.screen.OnboardFlow

class AuthenticationActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            MedPalAITheme {

                var visible by remember { mutableStateOf(true) }

                Scaffold(modifier = Modifier.fillMaxSize()) { innerPadding ->
                    Column(modifier = Modifier.padding(innerPadding)) {
                        if (visible) {
                          //  OnboardFlow(skip = visible, changeVal = { nVal -> visible = nVal })
                        } else {
                            Column(horizontalAlignment = Alignment.CenterHorizontally,
                                verticalArrangement = Arrangement.Center,
                                modifier = Modifier.fillMaxHeight()) {
                                Image(painter = painterResource(id = R.drawable.logo_green),
                                    contentDescription = "",
                                    contentScale = ContentScale.Fit,
                                    modifier = Modifier.size(100.dp))
                                Spacer(modifier = Modifier.height(20.dp))
                                Text(text = "Let's get started!")
                                Text(text = "Login to enjoy the features we've provided, and stay healthy!",
                                    color = Color.Gray,
                                    textAlign = TextAlign.Center)
                                Spacer(modifier = Modifier.height(20.dp))
                                Button(onClick = { /*TODO*/ },
                                    colors = ButtonDefaults.buttonColors(containerColor = colorResource(
                                        id = R.color.sea_green
                                    ))) {
                                    Text(text = "Login")
                                }
                                OutlinedButton(onClick = { /*TODO*/ },
                                    colors = ButtonDefaults.buttonColors(containerColor = Color.Transparent),
                                    border = BorderStroke(1.dp, colorResource(id = R.color.sea_green))
                                ) {
                                    Text(text = "Sign Up", color = colorResource(id = R.color.sea_green))
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
package com.healthiai.medpalai.activity

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.healthiai.medpalai.ui.screen.ArticlesSection
import com.healthiai.medpalai.ui.screen.CategoriesRow
import com.healthiai.medpalai.ui.screen.HeadingRow
import com.healthiai.medpalai.ui.screen.PromotionCard
import com.healthiai.medpalai.ui.screen.SearchBar
import com.healthiai.medpalai.ui.screen.TopDoctorsSection
import com.healthiai.medpalai.ui.theme.MedPalAITheme

class HomeActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            MedPalAITheme {
                var searchText by remember {
                    mutableStateOf("")
                }
                Scaffold() { innerPadding ->
                   Column(
                        modifier = Modifier
                            .padding(innerPadding)
                            .padding(20.dp)
                            .fillMaxSize()
                            .verticalScroll(rememberScrollState())
                    ) {

                        Spacer(modifier = Modifier.height(20.dp))
                        HeadingRow()
                        Spacer(modifier = Modifier.height(20.dp))
                        SearchBar(searchText, onSearchTextChanged = { text-> searchText = text })
                        Spacer(modifier = Modifier.height(20.dp))
                        CategoriesRow()
                        Spacer(modifier = Modifier.height(20.dp))
                        PromotionCard()
                        Spacer(modifier = Modifier.height(20.dp))
                        TopDoctorsSection()
                        Spacer(modifier = Modifier.height(20.dp))
                        ArticlesSection()
                    }
                }
            }
        }
    }
}
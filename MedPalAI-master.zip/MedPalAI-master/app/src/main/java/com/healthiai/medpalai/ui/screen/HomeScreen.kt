package com.healthiai.medpalai.ui.screen

import android.content.Intent
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ElevatedCard
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.unit.dp
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.colorResource
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat.startActivity
import androidx.navigation.NavController
import com.healthiai.medpalai.R
import com.healthiai.medpalai.activity.TopDoctorsActivity
import com.healthiai.medpalai.data.Article
import com.healthiai.medpalai.data.Doctor
import com.healthiai.medpalai.data.articleList
import com.healthiai.medpalai.data.doctorsList

@Composable
fun HomeScreen(navController: NavController) {
    var searchText by remember {
        mutableStateOf("")
    }
    Scaffold() { innerPadding ->
        Column(
            modifier = Modifier
                .padding(innerPadding)
                .padding(20.dp)
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
        ) {

            Spacer(modifier = Modifier.height(20.dp))
            HeadingRow()
            Spacer(modifier = Modifier.height(20.dp))
            SearchBar(searchText, onSearchTextChanged = { text-> searchText = text })
            Spacer(modifier = Modifier.height(20.dp))
            CategoriesRow()
            Spacer(modifier = Modifier.height(20.dp))
            PromotionCard()
            Spacer(modifier = Modifier.height(20.dp))
            TopDoctorsSection()
            Spacer(modifier = Modifier.height(20.dp))
            ArticlesSection()
        }
    }
}

@Composable
fun HeadingRow(){
    Row(
        horizontalArrangement = Arrangement.Center,
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier.fillMaxWidth()

    ) {
        Text(
            text = stringResource(id = R.string.home_heading),
            fontSize = 30.sp,
            fontWeight = FontWeight.Bold,
            modifier = Modifier
                .padding(10.dp)
                .weight(2f)

        )
        Icon(
            painterResource(id = R.drawable.bell_icon),
            contentDescription = null,
            modifier = Modifier
                .size(35.dp)
                .weight(1f)
        )
    }
}

@Composable
fun SearchBar(searchText: String, onSearchTextChanged:  (String) -> Unit){
    OutlinedTextField(
        value = searchText,
        onValueChange = onSearchTextChanged,
        modifier = Modifier.fillMaxWidth(),
        placeholder = { Text("Search doctor, drugs, articles...") },
        leadingIcon = {
            Icon(
                imageVector = Icons.Default.Search,
                contentDescription = null,
            )
        },
        shape = RoundedCornerShape(16.dp)
    )
}

@Composable
fun CategoriesRow(){
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        CategoryItem("Doctor", R.drawable.cat1)
        CategoryItem("Pharmacy", R.drawable.cat2)
        CategoryItem("Hospital", R.drawable.cat3)
        CategoryItem("Ambulance", R.drawable.cat4)
    }
}


@Composable
fun CategoryItem(name: String, iconId: Int) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Box(
            modifier = Modifier
                .size(80.dp)
                .clip(CircleShape)
                .background(colorResource(id = R.color.off_white)),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                painter = painterResource(id = iconId),
                contentDescription = null,
                modifier = Modifier.size(45.dp)
            )
        }
        Spacer(modifier = Modifier.height(8.dp))
        Text(text = name, fontSize = 12.sp)
    }
}

@Composable
fun PromotionCard(){
    ElevatedCard(
        elevation = CardDefaults.cardElevation(
            defaultElevation = 6.dp
        ),
        modifier = Modifier
            .fillMaxWidth()
            .size(180.dp)

    ) {
        Row(
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier
                .background(colorResource(id = R.color.off_white))
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            Column(
                modifier = Modifier.weight(2f)
            ) {
                Text(
                    text = stringResource(id = R.string.home_promotion),
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Bold,
                )
                Spacer(modifier = Modifier.height(8.dp))
                Button(
                    onClick = { /*TODO*/ },
                    colors = ButtonDefaults.buttonColors(colorResource(id = R.color.sea_green))
                ) {
                    Text(
                        text = "Learn More",
                    )
                }
            }
            Image(
                painter = painterResource(id = R.drawable.onboard_3) ,
                contentDescription = null,
                contentScale = androidx.compose.ui.layout.ContentScale.Companion.Crop,
                modifier = Modifier
                    .weight(1f)
            )
        }
    }
}

@Composable
fun CardView(title: String, cardItemList: List<Any>, isDoctorView: Boolean){
    val context = LocalContext.current
    Column {
        Row(
            modifier = Modifier
                .fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(text = title, fontWeight = FontWeight.Bold, fontSize = 20.sp
                )
            TextButton(onClick = {
                val intent = Intent(context, TopDoctorsActivity::class.java)
                context.startActivity(intent)
            }) {
                Text(text = "See all", fontSize = 16.sp, color = colorResource(id = R.color.sea_green))
            }
        }
        Spacer(modifier = Modifier.height(4.dp))
        if(isDoctorView) {
            LazyRow(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                items(cardItemList) { item ->
                    DoctorItem(item as Doctor)
                }
            }
        }else{
            LazyRow(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                items(cardItemList) { item ->
                    ArticleItem(item as Article)
                }
            }
        }
    }
}

@Composable
fun TopDoctorsSection(){
    val title = "Top Doctors"
    val cardItemList = doctorsList
    val isDoctorView = true
    CardView(title,cardItemList,isDoctorView)
}

@Composable
fun ArticlesSection(){
    val title = "Health Articles"
    val cardItemList = articleList
    val isDoctorView = false
    CardView(title,cardItemList,isDoctorView)
}

@Composable
fun DoctorItem(doctor: Doctor) {
    Card(
        shape = RoundedCornerShape(16.dp),
        modifier = Modifier
            .width(180.dp)
            .height(280.dp)
            .padding(4.dp)

    ) {
        Column(
            modifier = Modifier
                .background(colorResource(id = R.color.off_white))
                .fillMaxSize()
                .padding(8.dp),
            horizontalAlignment = Alignment.CenterHorizontally ,
            verticalArrangement = Arrangement.Center,
        ) {
            Image(
                painter = painterResource(id = doctor.imageId),
                contentDescription = null,
                modifier = Modifier
                    .size(80.dp)
                    .clip(CircleShape)
            )
            Spacer(modifier = Modifier.height(2.dp))
            Text(text = doctor.name, fontWeight = FontWeight.Bold, fontSize = 16.sp)
            Spacer(modifier = Modifier.height(2.dp))
            Text(text = doctor.specialization, fontSize = 14.sp, color = Color.Gray)
            Spacer(modifier = Modifier.height(8.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.Center,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(painterResource(id = R.drawable.rating), contentDescription = null, modifier = Modifier.size(12.dp))
                Spacer(modifier = Modifier.width(2.dp))
                Text(text = doctor.rating, fontWeight = FontWeight.Bold, fontSize = 12.sp,color = colorResource(id = R.color.sea_green))
                Spacer(modifier = Modifier.width(8.dp))
                Icon(painterResource(id = R.drawable.location), contentDescription = null, modifier = Modifier.size(12.dp))
                Spacer(modifier = Modifier.width(2.dp))
                Text(text = doctor.distance, fontWeight = FontWeight.Bold, fontSize = 12.sp,color = colorResource(id = R.color.light_brown))
            }
        }
    }
}


@Composable
fun ArticleItem(article: Article) {
    Card(
        shape = RoundedCornerShape(16.dp),
        modifier = Modifier
            .width(160.dp)
            .height(180.dp)
            .padding(8.dp)

    ) {
        Row(
            modifier = Modifier
                .background(colorResource(id = R.color.off_white))
                .fillMaxSize(),
            verticalAlignment = Alignment.CenterVertically ,
            horizontalArrangement = Arrangement.Center,
        ) {
            Image(
                painter = painterResource(id = article.imageId),
                contentDescription = null,
                modifier = Modifier
                    .size(80.dp)
                    .clip(CircleShape)
            )
            Spacer(modifier = Modifier.height(2.dp))
            Text(text = article.contentHeading, fontWeight = FontWeight.Bold, fontSize = 16.sp)
        }
    }
}




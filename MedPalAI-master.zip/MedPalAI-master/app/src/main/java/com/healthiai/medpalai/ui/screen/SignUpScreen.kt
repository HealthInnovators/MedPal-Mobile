package com.healthiai.medpalai.ui.screen

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Visibility

import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.painter.Painter
import androidx.compose.ui.res.colorResource
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.healthiai.medpalai.R


@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SignUpScreen(navController: NavController) {
    val email = remember { mutableStateOf("") }
    val password = remember { mutableStateOf("") }
    val confirmPassword = remember { mutableStateOf("") }
    var showDialog by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text(text = "Sign Up", style = MaterialTheme.typography.bodyLarge, color = colorResource(R.color.sea_green))

        Spacer(modifier = Modifier.height(16.dp))

        OutlinedTextField(
            shape = RoundedCornerShape(24.dp),
            value = email.value,
            onValueChange = { email.value = it },
            label = { Text("Enter your Email", color = colorResource(id = R.color.black)) },
            modifier = Modifier.fillMaxWidth(),
            colors = TextFieldDefaults.outlinedTextFieldColors(
                focusedBorderColor = colorResource(R.color.sea_green),
                unfocusedBorderColor = colorResource(R.color.black),
                containerColor = colorResource(R.color.white)
            )
        )

        Spacer(modifier = Modifier.height(8.dp))

        OutlinedTextField(
            shape = RoundedCornerShape(24.dp),
            value = password.value,
            onValueChange = { password.value = it },
            label = { Text("Enter your Password", color = colorResource(id = R.color.black)) },
            modifier = Modifier.fillMaxWidth(),
            visualTransformation = PasswordVisualTransformation(),
            colors = TextFieldDefaults.outlinedTextFieldColors(
                focusedBorderColor = colorResource(R.color.sea_green),
                unfocusedBorderColor = colorResource(R.color.black),
                containerColor = colorResource(R.color.white)
            )
        )

        Spacer(modifier = Modifier.height(8.dp))

        OutlinedTextField(
            shape = RoundedCornerShape(24.dp),
            value = confirmPassword.value,
            onValueChange = { confirmPassword.value = it },
            label = { Text("Confirm Password", color = colorResource(id = R.color.black)) },
            modifier = Modifier.fillMaxWidth(),
            visualTransformation = PasswordVisualTransformation(),
            colors = TextFieldDefaults.outlinedTextFieldColors(
                focusedBorderColor = colorResource(R.color.sea_green),
                unfocusedBorderColor = colorResource(R.color.black),
                containerColor = colorResource(R.color.white)
            )
        )

        Spacer(modifier = Modifier.height(16.dp))

        OutlinedButton(
            onClick = {
                // Handle signup logic
                if (signup(email.value, password.value, confirmPassword.value)) {
                    // Navigate to home screen upon successful signup
                    showDialog = true;

                } else {
                    // Show error message
                }
            },
            shape = RoundedCornerShape(24.dp),
            colors = ButtonDefaults.outlinedButtonColors(
                containerColor = colorResource(R.color.sea_green)
            ),
            modifier = Modifier
                .fillMaxWidth()
                .height(56.dp)
        ) {
            Text(text = "Sign Up", style = MaterialTheme.typography.bodyLarge, color = colorResource(R.color.white))
        }

        if (showDialog) {
            AlertDialog(
                onDismissRequest = { showDialog = false },
                title = { Text(text = "Success") },
                text = { Text("Account created successfully.") },
                confirmButton = {
                    Button(
                        onClick = { showDialog = false
                                    navController.navigate("login")
                                  },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = colorResource(id = R.color.sea_green), // Background color
                            contentColor = colorResource(id = R.color.white) // Text color
                        )
                    ) {
                        Text("OK")
                    }
                }
            )
        }
    }
}

fun signup(email: String, password: String, confirmPassword: String): Boolean {
    // Replace with actual signup logic, including validation
    return email.isNotEmpty() && password == confirmPassword
}


package com.healthiai.medpalai.activity

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.runtime.Composable
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.healthiai.medpalai.ui.screen.AuthenticationScreen
import com.healthiai.medpalai.ui.screen.ForgotPasswordScreen
import com.healthiai.medpalai.ui.screen.LoginScreen
import com.healthiai.medpalai.ui.screen.SignUpScreen
import com.healthiai.medpalai.ui.screen.ForgotPasswordScreen
import com.healthiai.medpalai.ui.screen.HomeScreen


class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            val navController = rememberNavController()
            AppNavHost(navController = navController)
        }
    }
}

sealed class Screen(val route: String) {
    object Home : Screen("home")
    object TopDoctors : Screen("top_doctors")
    object Authentication : Screen("authentication")
    object Login : Screen("login")
    object SignUpScreen : Screen("signup")
    object ForgotPassword : Screen("forgot password")
}


@Composable
fun AppNavHost(navController: NavHostController) {
    NavHost(navController = navController, startDestination = Screen.Authentication.route) {
        composable(Screen.Home.route) {
            HomeScreen(navController)
        }
//        composable(Screen.TopDoctors.route) {
//            TopDoctorsScreen(navController)
//        }
        composable(Screen.Authentication.route) {
            AuthenticationScreen(navController)
        }
        composable(Screen.Login.route) {
            LoginScreen(navController)
        }
        composable(Screen.SignUpScreen.route) {
            SignUpScreen(navController)
        }
        composable(Screen.ForgotPassword.route) {
            ForgotPasswordScreen(navController)
        }

    }
}
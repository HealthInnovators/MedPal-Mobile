package com.healthiai.medpalai.ui.screen

import android.content.Intent
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Card
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.RectangleShape
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.colorResource
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.healthiai.medpalai.R
import com.healthiai.medpalai.activity.HomeActivity
import com.healthiai.medpalai.activity.TopDoctorsActivity
import com.healthiai.medpalai.data.Doctor
import com.healthiai.medpalai.data.doctorsList


@Composable
fun DoctorHeading(){
    val context = LocalContext.current
    Row(
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier.fillMaxWidth()
    ) {
        Icon(
            painterResource(id = R.drawable.back),
            contentDescription = null,
            modifier = Modifier
                .size(20.dp)
                .weight(1f)
                .clickable {
                    val intent = Intent(context, HomeActivity::class.java)
                    context.startActivity(intent)
                }
        )
        Text(
            text = stringResource(id = R.string.topdoc_heading),
            fontSize = 20.sp,
            fontWeight = FontWeight.Bold,
            textAlign = TextAlign.Center,
            modifier = Modifier
                .padding(10.dp)
                .weight(2f)
        )
        Icon(
            painterResource(id = R.drawable.menu),
            contentDescription = null,
            modifier = Modifier
                .size(20.dp)
                .weight(1f)
        )
    }
}

@Composable
fun TopDoctorsList(){
    LazyColumn(
        modifier = Modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.SpaceBetween
    ) {
        items(doctorsList) { item ->
            DoctorCard(doctor = item)
        }
    }
}


@Composable
fun DoctorCard(doctor: Doctor) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .height(200.dp)
            .padding(10.dp)
    ) {
        Row(
            modifier = Modifier
                .background(colorResource(id = R.color.off_white))
                .fillMaxSize()
                .padding(20.dp),
            verticalAlignment = Alignment.CenterVertically ,
        ) {
            Image(
                painter = painterResource(id = doctor.imageId),
                contentDescription = null,
                modifier = Modifier
                    .size(150.dp)
                    .clip(CircleShape)
            )
            Column(
                    verticalArrangement = Arrangement.SpaceBetween,
                    modifier = Modifier.padding(10.dp)
            ){
                Text(text = doctor.name, fontWeight = FontWeight.Bold, fontSize = 20.sp)
                Text(text = doctor.specialization, fontSize = 16.sp)
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.Start
                ){
                    Icon(painterResource(id = R.drawable.rating), contentDescription = null, modifier = Modifier.size(12.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(text = doctor.rating, fontSize = 16.sp,color = colorResource(id = R.color.sea_green))
                }
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.Start
                ){
                    Icon(painterResource(id = R.drawable.location), contentDescription = null, modifier = Modifier.size(12.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(text = doctor.distance, fontSize = 16.sp,color = colorResource(id = R.color.light_brown))
                }
            }
        }
    }
}
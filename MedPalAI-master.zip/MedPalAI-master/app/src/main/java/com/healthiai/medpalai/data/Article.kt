package com.healthiai.medpalai.data

import com.healthiai.medpalai.R

data class Article(val imageId: Int, val contentHeading: String)

val articleList = listOf(
    Article( R.drawable.onboard_1,"Cardiologist"),
    Article( R.drawable.onboard_1,"Psychologist",),
    Article( R.drawable.onboard_1,"Orthopedist"),
    Article( R.drawable.onboard_1,"Neurologist")
)
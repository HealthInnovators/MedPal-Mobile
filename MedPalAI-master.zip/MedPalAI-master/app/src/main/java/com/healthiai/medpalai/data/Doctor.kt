package com.healthiai.medpalai.data

import com.healthiai.medpalai.R

data class Doctor(val name: String, val specialization: String, val imageId: Int, val rating: String, val distance: String)

val doctorsList = listOf(
    Doctor("Dr. Marcus Horiz", "Cardiologist", R.drawable.onboard_1,"4.5","800m away"),
    Doctor("Dr. Maria Elena", "Psychologist", R.drawable.onboard_1,"4.7","600m away"),
    Doctor("Dr. Stevi Jess", "Orthopedist", R.drawable.onboard_1,"3.5","400m away"),
    Doctor("Dr. John Doe", "Neurologist", R.drawable.onboard_1,"4.2","1200m away"),
    Doctor("Dr. Marcus Horiz", "Cardiologist", R.drawable.onboard_1,"4.5","800m away"),
    Doctor("Dr. Maria Elena", "Psychologist", R.drawable.onboard_1,"4.7","600m away"),
    Doctor("Dr. Stevi Jess", "Orthopedist", R.drawable.onboard_1,"3.5","400m away"),
    Doctor("Dr. John Doe", "Neurologist", R.drawable.onboard_1,"4.2","1200m away")
)

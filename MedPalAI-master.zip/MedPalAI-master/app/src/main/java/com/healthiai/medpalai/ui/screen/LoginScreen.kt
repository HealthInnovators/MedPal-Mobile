package com.healthiai.medpalai.ui.screen

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.painter.Painter
import androidx.compose.ui.res.colorResource
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.healthiai.medpalai.R


@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LoginScreen(navController: NavController) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        TopAppBar(
            title = { Text(text = "Login", style = MaterialTheme.typography.bodyLarge, fontSize = 24.sp, fontWeight = FontWeight.Bold) },
            navigationIcon = {
                IconButton(onClick = { /* Handle back navigation */ }) {
                    Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = Color.Black)
                }
            },
            colors = TopAppBarDefaults.topAppBarColors(
                containerColor = Color.Transparent
            )
        )

        Spacer(modifier = Modifier.height(32.dp))

        var email by remember { mutableStateOf("") }
        var password by remember { mutableStateOf("") }
        var passwordVisible by remember { mutableStateOf(false) }

        OutlinedTextField(
            value = email,
            onValueChange = { email = it },
            label = { Text("Enter your email", color = colorResource(id = R.color.black))},
            shape = RoundedCornerShape(24.dp),
            colors = TextFieldDefaults.outlinedTextFieldColors(
                focusedBorderColor = colorResource(R.color.sea_green),
                unfocusedBorderColor = colorResource(R.color.black),
                containerColor = colorResource(R.color.white)
            ),
            modifier = Modifier
                .fillMaxWidth()
                .height(56.dp)
        )

        Spacer(modifier = Modifier.height(16.dp))

        OutlinedTextField(
            value = password,
            onValueChange = { password = it },
            label = { Text("Enter your password", color = colorResource(id = R.color.black))},
           // leadingIcon = { Icon(painterResource(id = R.drawable.password), contentDescription = null) },
            trailingIcon = {
                val image = if (passwordVisible) Icons.Default.Visibility else Icons.Default.VisibilityOff
                IconButton(onClick = { passwordVisible = !passwordVisible }) {

                }
            },
            visualTransformation = if (passwordVisible) VisualTransformation.None else PasswordVisualTransformation(),
            shape = RoundedCornerShape(24.dp),
            colors = TextFieldDefaults.outlinedTextFieldColors(
                focusedBorderColor = colorResource(R.color.sea_green),
                unfocusedBorderColor = colorResource(R.color.black),
                containerColor = colorResource(R.color.white)
            ),
            modifier = Modifier
                .fillMaxWidth()
                .height(56.dp)
        )

        Spacer(modifier = Modifier.height(8.dp))

        Text(
            text = "Forgot Password?",
            color = colorResource(id = R.color.black),
            modifier = Modifier
                .align(Alignment.End)
                .clickable { navController.navigate("forgot password") }

        )

        Spacer(modifier = Modifier.height(32.dp))

        Button(
            onClick = { navController.navigate("home") },
            shape = RoundedCornerShape(24.dp),
            colors = ButtonDefaults.buttonColors(containerColor = colorResource(R.color.sea_green)),
            modifier = Modifier
                .fillMaxWidth()
                .height(56.dp)
        ) {
            Text("Login", fontSize = 18.sp, color = colorResource(R.color.black))
        }

        Spacer(modifier = Modifier.height(16.dp))

        Text(
            text = "Don't have an account? Sign Up",
            color = colorResource(R.color.black),
            modifier = Modifier
                .align(Alignment.End)
                .clickable { navController.navigate("signup") }
        )

        Spacer(modifier = Modifier.height(32.dp))

        Text("OR", color = Color.Gray)

        Spacer(modifier = Modifier.height(32.dp))
//
        SignInButton(
            text = "Sign in with Google",
            icon = painterResource(id = R.drawable.google),
            backgroundColor = colorResource(id = R.color.white),
            textColor = Color.Gray,
            borderColor = Color.White

        )

        Spacer(modifier = Modifier.height(16.dp))

       SignInButton(
            text = "Sign in with Apple",
            icon = painterResource(id = R.drawable.img),
            backgroundColor =colorResource(id = R.color.white),
            textColor = Color.Gray,
            borderColor = Color.White
        )

        Spacer(modifier = Modifier.height(16.dp))

        SignInButton(
            text = "Sign in with Facebook",
            icon = painterResource(id = R.drawable.meta),
            backgroundColor = colorResource(id = R.color.white),
            textColor = Color.Gray,
            borderColor = Color.White
        )
    }
}

@Composable
fun SignInButton(
    text: String,
    icon: Painter,
    backgroundColor: Color,
    textColor: Color,
    borderColor: Color

) {
    OutlinedButton(
        onClick = { /* Handle sign-in */ },
        shape = RoundedCornerShape(24.dp),
        colors = ButtonDefaults.outlinedButtonColors(
            containerColor = backgroundColor,
            contentColor = textColor
        ),
        modifier = Modifier
            .fillMaxWidth()
            .height(56.dp)
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.Start,
            modifier = Modifier.fillMaxWidth()
        ) {
            val imageModifier = Modifier
                .size(95.dp) // Initial size
                .background(Color.White)
            Image(
                painter = icon,
                contentDescription = null,
                modifier = imageModifier
                //contentScale = ContentScale.FIT// Ensure the icon's original color is used
                //contentScale = ContentScale.FIT// Ensure the icon's original color is used
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                text = text,
                color = textColor
               // Use appropriate text style
            )
        }
    }
}

//@Composable
//fun SignInButton(
//    text: String,
//    icon: Painter,
//    backgroundColor: Color,
//    textColor: Color,
//    borderColor: Color,
//    //onClick: () -> Unit,
//) {
//    OutlinedButton(
//        //onClick = onClick,
//        shape = RoundedCornerShape(24.dp),
//        colors = ButtonDefaults.outlinedButtonColors(
//            containerColor = backgroundColor,
//            contentColor = textColor
//        ),
//        border = BorderStroke(1.dp, borderColor),
//        modifier = Modifier
//            .fillMaxWidth()
//            .height(56.dp)
//    ) {
////        Box(
////            contentAlignment = Alignment.Center,
////            modifier = Modifier.fillMaxSize()
////        )
//        Row(
//            verticalAlignment = Alignment.CenterVertically,
//            horizontalArrangement = Arrangement.Center,
//
//        modifier = Modifier.fillMaxWidth()
//        ) {
//        Icon(
//
//        painter = icon,
//        contentDescription = "Sign in icon", // Add a generic description
//        modifier = Modifier
//            .size(24.dp)
//            .weight(1f)
//            .aspectRatio(1f),
//        tint = Color.Unspecified
//        )
//        Spacer(modifier = Modifier.width(8.dp))
//    }
//    }
//}



